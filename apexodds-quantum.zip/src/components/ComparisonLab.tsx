import React, { useState } from "react";
import { Sparkles, BrainCircuit, RefreshCw, BarChart2, ShieldAlert } from "lucide-react";

export default function ComparisonLab() {
  const [teamA, setTeamA] = useState("Chiefs");
  const [teamB, setTeamB] = useState("Bills");

  const [offenseA, setOffenseA] = useState(87);
  const [offenseB, setOffenseB] = useState(81);
  
  const [defenseA, setDefenseA] = useState(91);
  const [defenseB, setDefenseB] = useState(84);

  const [formA, setFormA] = useState(88);
  const [formB, setFormB] = useState(90);

  const [coachA, setCoachA] = useState(85);
  const [coachB, setCoachB] = useState(78);

  const [isLoading, setIsLoading] = useState(false);

  const recalculateLabMetrics = () => {
    setIsLoading(true);
    setTimeout(() => {
      // Create interesting randomized parameters
      setOffenseA(Math.floor(Math.random() * 20) + 76);
      setOffenseB(Math.floor(Math.random() * 20) + 76);

      setDefenseA(Math.floor(Math.random() * 20) + 76);
      setDefenseB(Math.floor(Math.random() * 20) + 76);

      setFormA(Math.floor(Math.random() * 20) + 76);
      setFormB(Math.floor(Math.random() * 20) + 76);

      setCoachA(Math.floor(Math.random() * 20) + 76);
      setCoachB(Math.floor(Math.random() * 20) + 76);

      setIsLoading(false);
    }, 600);
  };

  const getVerdictText = () => {
    const powerA = (offenseA + defenseA + formA + coachA) / 4;
    const powerB = (offenseB + defenseB + formB + coachB) / 4;
    
    if (powerA > powerB) {
      return `Neural comparison filters strongly favor ${teamA} (Model delta: +${(powerA - powerB).toFixed(1)}%). High defensive indices paired with tactical rest cycles yield a secure home field probability advantage.`;
    } else {
      return `Comparative telemetry favors ${teamB} (Model delta: +${(powerB - powerA).toFixed(1)}%). Outstanding offensive output parameters and peak form values suggest potential underdog variance.`;
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 select-none">
      <div>
        <h3 className="text-lg font-extrabold text-white">Visual Comparison Laboratory</h3>
        <p className="text-xs text-slate-400">Perform real-time comparison analytics between active sports franchises.</p>
      </div>

      {/* Select matrix rows */}
      <div className="grid md:grid-cols-5 gap-4 items-center pt-2">
        <div className="md:col-span-2 space-y-1.5">
          <label className="block text-[10px] uppercase font-bold text-slate-500 font-mono tracking-wider">Franchise (Team A)</label>
          <select 
            value={teamA}
            onChange={(e) => setTeamA(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 hover:border-indigo-500/30 p-4 rounded-2xl outline-none focus:border-indigo-550 text-sm font-semibold cursor-pointer text-slate-200"
          >
            <option value="Chiefs" className="bg-slate-955 text-slate-100">🏈 KC Chiefs</option>
            <option value="Bills" className="bg-slate-955 text-slate-100">🏈 BUF Bills</option>
            <option value="Celtics" className="bg-slate-955 text-slate-100">🏀 BOS Celtics</option>
            <option value="Knicks" className="bg-slate-955 text-slate-100">🏀 NY Knicks</option>
            <option value="Ravens" className="bg-slate-955 text-slate-100">🏈 BAL Ravens</option>
            <option value="Eagles" className="bg-slate-955 text-slate-100">🏈 PHI Eagles</option>
          </select>
        </div>

        <div className="flex justify-center text-indigo-400 font-extrabold font-mono text-lg py-2 md:py-0">
          VS
        </div>

        <div className="md:col-span-2 space-y-1.5">
          <label className="block text-[10px] uppercase font-bold text-slate-500 font-mono tracking-wider">Comparison (Team B)</label>
          <select 
            value={teamB}
            onChange={(e) => setTeamB(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 hover:border-indigo-500/30 p-4 rounded-2xl outline-none focus:border-indigo-550 text-sm font-semibold cursor-pointer text-slate-200"
          >
            <option value="Bills" className="bg-slate-955 text-slate-100">🏈 BUF Bills</option>
            <option value="Chiefs" className="bg-slate-955 text-slate-100">🏈 KC Chiefs</option>
            <option value="Knicks" className="bg-slate-955 text-slate-100">🏀 NY Knicks</option>
            <option value="Celtics" className="bg-slate-955 text-slate-100">🏀 BOS Celtics</option>
            <option value="Ravens" className="bg-slate-955 text-slate-100">🏈 BAL Ravens</option>
            <option value="Eagles" className="bg-slate-955 text-slate-100">🏈 PHI Eagles</option>
          </select>
        </div>
      </div>

      {/* Numerical Metrics and progress bars comparison */}
      <div className="grid md:grid-cols-2 gap-8 pt-6 border-t border-slate-850/80">
        
        <div className="bg-slate-950 p-6 rounded-2xl border border-slate-850/80 flex flex-col justify-between">
          <h4 className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold mb-4 flex items-center gap-1.5">
            <BarChart2 className="w-3.5 h-3.5 text-indigo-400" />
            Core Analytics Telemetry
          </h4>

          <div className="space-y-4">
            
            {/* Metric 1 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-300 font-semibold font-mono">
                <span>Offense Output Rating</span>
                <span className="text-indigo-400">{offenseA} vs {offenseB}</span>
              </div>
              <div className="h-2 bg-slate-900 rounded-full flex overflow-hidden">
                <div 
                  className="bg-indigo-400 h-full rounded-l transition-all duration-500" 
                  style={{ width: `${(offenseA / (offenseA + offenseB)) * 100}%` }}
                />
                <div 
                  className="bg-indigo-650 h-full rounded-r transition-all duration-500" 
                  style={{ width: `${(offenseB / (offenseA + offenseB)) * 100}%` }}
                />
              </div>
            </div>

            {/* Metric 2 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-300 font-semibold font-mono">
                <span>Defense Effectiveness Index</span>
                <span className="text-indigo-400">{defenseA} vs {defenseB}</span>
              </div>
              <div className="h-2 bg-slate-900 rounded-full flex overflow-hidden">
                <div 
                  className="bg-indigo-400 h-full rounded-l transition-all duration-500" 
                  style={{ width: `${(defenseA / (defenseA + defenseB)) * 100}%` }}
                />
                <div 
                  className="bg-indigo-650 h-full rounded-r transition-all duration-500" 
                  style={{ width: `${(defenseB / (defenseA + defenseB)) * 100}%` }}
                />
              </div>
            </div>

            {/* Metric 3 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-300 font-semibold font-mono">
                <span>Form & Momentum Ratio</span>
                <span className="text-indigo-400">{formA} vs {formB}</span>
              </div>
              <div className="h-2 bg-slate-900 rounded-full flex overflow-hidden">
                <div 
                  className="bg-indigo-400 h-full rounded-l transition-all duration-500" 
                  style={{ width: `${(formA / (formA + formB)) * 100}%` }}
                />
                <div 
                  className="bg-indigo-650 h-full rounded-r transition-all duration-500" 
                  style={{ width: `${(formB / (formA + formB)) * 100}%` }}
                />
              </div>
            </div>

            {/* Metric 4 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-300 font-semibold font-mono">
                <span>Coaching Strategy Factor</span>
                <span className="text-indigo-400">{coachA} vs {coachB}</span>
              </div>
              <div className="h-2 bg-slate-900 rounded-full flex overflow-hidden">
                <div 
                  className="bg-indigo-400 h-full rounded-l transition-all duration-500" 
                  style={{ width: `${(coachA / (coachA + coachB)) * 100}%` }}
                />
                <div 
                  className="bg-indigo-650 h-full rounded-r transition-all duration-500" 
                  style={{ width: `${(coachB / (coachA + coachB)) * 100}%` }}
                />
              </div>
            </div>

          </div>

          {/* Color Guides footer */}
          <div className="flex gap-4 text-[10px] uppercase tracking-wider font-bold text-slate-500 font-mono mt-6 pt-3 border-t border-slate-850/80">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-indigo-400 block" />
              <span>{teamA}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-indigo-650 block" />
              <span>{teamB}</span>
            </div>
          </div>
        </div>

        {/* Competitive verdict panel */}
        <div className="bg-slate-950 p-6 rounded-2xl border border-slate-850/80 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <BrainCircuit className="w-5 h-5 text-indigo-400 animate-pulse" />
              <span className="text-[10px] uppercase font-bold tracking-widest text-white">AI Compare Output Verdict</span>
            </div>
            {isLoading ? (
              <div className="space-y-2 py-4 animate-pulse">
                <div className="h-4 bg-slate-800 rounded w-full" />
                <div className="h-4 bg-slate-800 rounded w-5/6" />
                <div className="h-4 bg-slate-800 rounded w-2/3" />
              </div>
            ) : (
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {getVerdictText()}
              </p>
            )}
          </div>

          <button 
            onClick={recalculateLabMetrics}
            disabled={isLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-xl text-xs transition shadow-md uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Simulating Parameters...</span>
              </>
            ) : (
              <>
                <span>Compile Visual Laboratory</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
}
